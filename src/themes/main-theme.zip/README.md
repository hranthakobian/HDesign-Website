# HDesign Emerald Theme Package

Այս ZIP փաթեթը նախատեսված է Մողէզի (Moxez) համակարգ ներածելու համար:
